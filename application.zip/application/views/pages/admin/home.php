
	<h1>Admin Dashboard</h1><hr>
	<div class="row">
		<div class="col-md-6">
			<h3>10 entri terakhir:</h3>
			<div class="btn-group-vertical  btn-block">
			<a class="button-dl btn btn-outline-info btn-md  text-left" href="<?php echo base_url('admin/status')."?cid=11012"; ?>"><i class="fa fa-users" aria-hidden="true"></i>supra.biz.id</a>
			<a class="button-dl btn btn-outline-info btn-md  text-left" href="<?php echo base_url('admin/status')."?cid=11012"; ?>"><i class="fa fa-graduation-cap" aria-hidden="true"></i>supra.biz.id</a>
			<a class="button-dl btn btn-outline-info btn-md  text-left" href="<?php echo base_url('admin/status')."?cid=11012"; ?>"><i class="fa fa-shopping-cart" aria-hidden="true"></i>supra.biz.id</a>
			<a class="button-dl btn btn-outline-info btn-md  text-left" href="<?php echo base_url('admin/status')."?cid=11012"; ?>"><i class="fa fa-map-marker" aria-hidden="true"></i>wonosobo.desa.id</a>
			<a class="button-dl btn btn-outline-info btn-md  text-left" href="<?php echo base_url('admin/status')."?cid=11012"; ?>"><i class="fa fa-shopping-cart" aria-hidden="true"></i>supra.biz.id</a>
			<a class="button-dl btn btn-outline-info btn-md  text-left" href="<?php echo base_url('admin/status')."?cid=11012"; ?>"><i class="fa fa-users" aria-hidden="true"></i>supra.biz.id</a>
			<a class="button-dl btn btn-outline-info btn-md  text-left" href="<?php echo base_url('admin/status')."?cid=11012"; ?>"><i class="fa fa-graduation-cap" aria-hidden="true"></i>supra.biz.id</a>
			<a class="button-dl btn btn-outline-info btn-md  text-left" href="<?php echo base_url('admin/status')."?cid=11012"; ?>"><i class="fa fa-shopping-cart" aria-hidden="true"></i>supra.biz.id</a>
			<a class="button-dl btn btn-outline-info btn-md  text-left" href="<?php echo base_url('admin/status')."?cid=11012"; ?>"><i class="fa fa-map-marker" aria-hidden="true"></i>wonosobo.desa.id</a>
			<a class="button-dl btn btn-outline-info btn-md  text-left" href="<?php echo base_url('admin/status')."?cid=11012"; ?>"><i class="fa fa-shopping-cart" aria-hidden="true"></i>supra.biz.id</a>
			</div>
		</div>
		<div class="col-md-6">
			<h3>10 pengkinian terakhir:</h3>
			<div class="btn-group-vertical  btn-block">
			<a class="button-dl btn btn-outline-warning btn-md  text-left" href="<?php echo base_url('admin/status')."?cid=11012"; ?>"><i class="fa fa-users" aria-hidden="true"></i>supra.biz.id</a>
			<a class="button-dl btn btn-outline-warning btn-md  text-left" href="<?php echo base_url('admin/status')."?cid=11012"; ?>"><i class="fa fa-graduation-cap" aria-hidden="true"></i>supra.biz.id</a>
			<a class="button-dl btn btn-outline-warning btn-md  text-left" href="<?php echo base_url('admin/status')."?cid=11012"; ?>"><i class="fa fa-shopping-cart" aria-hidden="true"></i>supra.biz.id</a>
			<a class="button-dl btn btn-outline-warning btn-md  text-left" href="<?php echo base_url('admin/status')."?cid=11012"; ?>"><i class="fa fa-map-marker" aria-hidden="true"></i>wonosobo.desa.id</a>
			<a class="button-dl btn btn-outline-warning btn-md  text-left" href="<?php echo base_url('admin/status')."?cid=11012"; ?>"><i class="fa fa-shopping-cart" aria-hidden="true"></i>supra.biz.id</a>
			<a class="button-dl btn btn-outline-warning btn-md  text-left" href="<?php echo base_url('admin/status')."?cid=11012"; ?>"><i class="fa fa-users" aria-hidden="true"></i>supra.biz.id</a>
			<a class="button-dl btn btn-outline-warning btn-md  text-left" href="<?php echo base_url('admin/status')."?cid=11012"; ?>"><i class="fa fa-graduation-cap" aria-hidden="true"></i>supra.biz.id</a>
			<a class="button-dl btn btn-outline-warning btn-md  text-left" href="<?php echo base_url('admin/status')."?cid=11012"; ?>"><i class="fa fa-shopping-cart" aria-hidden="true"></i>supra.biz.id</a>
			<a class="button-dl btn btn-outline-warning btn-md  text-left" href="<?php echo base_url('admin/status')."?cid=11012"; ?>"><i class="fa fa-map-marker" aria-hidden="true"></i>wonosobo.desa.id</a>
			<a class="button-dl btn btn-outline-warning btn-md  text-left" href="<?php echo base_url('admin/status')."?cid=11012"; ?>"><i class="fa fa-shopping-cart" aria-hidden="true"></i>supra.biz.id</a>
			</div>
		</div>
	</div>