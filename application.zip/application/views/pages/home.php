
	<h1>Sistem Monitoring Bantuan Pemerintah</h1>
	<br>
	<img class="image-block" src="<?php echo base_url('assets'); ?>/images/1jutadomain-logo.png" alt="1 juta domain"><br>
	<p class="lead">
		<br>
		Program 1 Juta Domain .ID adalah Bantuan Pemerintah kepada masyarakat yang dikhususkan untuk UMKM, Sekolah, Pesantren, Komunitas dan Desa berupa pemberian Domain dan Hosting secara gratis selama 1 (satu) Tahun. Diharapkan dengan adanya Program 1 Juta Domain .ID, Dunia pendidikan dapat mendukung tumbuhnya konten positif di Indonesia, Komunitas dapat mendorong tumbuhnya inovasi kreatif dalam negeri, UMKM yang berpotensial dapat difasilitasi menjadi pelaku bisnis online dan Desa dapat memperkenalkan potensi desa masing-masing ke pihak luar.
	</p>