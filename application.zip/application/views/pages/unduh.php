
	<h1>Unduh Dokumen terkatit</h1>
	<div>
		<br>
		<a class="button-dl btn btn-outline-info btn-lg" href="<?php echo base_url('docs/a. pedoman umum.pdf'); ?>" download="1Juta Domain - Pedoman Umum"><i class="fa fa-download" aria-hidden="true"></i> PEDOMAN UMUM BANTUAN PEMERINTAH</a>
		<a class="button-dl btn btn-outline-info btn-lg" href="<?php echo base_url('docs/b. Petunjuk Teknis.pdf'); ?>" download="1Juta Domain - Petunjuk Teknis"><i class="fa fa-download" aria-hidden="true"></i> PETUNJUK TEKNIS BANTUAN 1 JUTA DOMAIN .ID</a>
		<a class="button-dl btn btn-outline-info btn-lg" href="<?php echo base_url('docs/c. Materi Umum.pdf'); ?>" download="1Juta Domain - Materi Umum"><i class="fa fa-download" aria-hidden="true"></i> MATERI DOMAIN .ID</a>
		<a class="button-dl btn btn-outline-info btn-lg" href="<?php echo base_url('docs/d. form calon penerima domain.pdf'); ?>" download="1Juta Domain - Formulir Pendaftaran"><i class="fa fa-download" aria-hidden="true"></i> FORMULIR PENDAFTARAN BANTUAN</a>
	</div>