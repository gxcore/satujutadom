
	<h1>Hubungi kami</h1>
	<p>
	Untuk Informasi Lebih Lanjut, Hubungi kami :<br>
	<br>
	<strong>Direktorat Pemberdayaan Informatika<br>
	Direktorat Jenderal Aplikasi Informatika<br>
	Kementerian Komunikasi dan Informatika</strong><br>
	Gedung Utama Lantai 3<br>
	Jalan Medan Merdeka Barat No.9, Jakarta Pusat, 10110
	</p>
	<div class="btn-group">
	<a class="button-dl btn btn-outline-success btn-lg" href="tel:+62 21 3503962"><i class="fa fa-phone" aria-hidden="true"></i>021 3503962</a>
	<a class="button-dl btn btn-outline-success btn-lg" href="tel:+62 21 3503962"><i class="fa fa-fax" aria-hidden="true"></i>021 3503962</a>
	</div><br><br>
	<div class="btn-group-vertical">
	<a class="button-dl btn btn-outline-success btn-lg" href="mailto:sisw007@kominfo.go.id"><i class="fa fa-envelope" aria-hidden="true"></i>sisw007@kominfo.go.id</a>
	<a class="button-dl btn btn-outline-success btn-lg" href="mailto:rang002@kominfo.go.id"><i class="fa fa-envelope" aria-hidden="true"></i>rang002@kominfo.go.id</a>
	<a class="button-dl btn btn-outline-success btn-lg" href="mailto:maur001@kominfo.go.id"><i class="fa fa-envelope" aria-hidden="true"></i>maur001@kominfo.go.id</a>
	</div>